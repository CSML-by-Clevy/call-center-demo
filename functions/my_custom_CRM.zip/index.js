/**
 * This function is setup to run on nodejs 12.x:
 * https://nodejs.org/dist/latest-v12.x/docs/api/
 * 
 * See the documentation:
 * https://docs.csml.dev/studio/getting-started/using-csml-apps#using-custom-code
 */
exports.handler = async (event) => {
  // --- add your code below this line ---

  if (event.action === "get_case") {
    return {
      id: 12345,
      customer_id: 12345,
      status: "pending",
      data: "This is a fake case for demonstration purposes only"
    }
  }

  if (event.action === "create_case") {
    return {
      id: 12345,
      customer_id: 12345,
      status: "pending",
      data: "This is a fake case for demonstration purposes only"
    };
  }

  if (event.action === "get_customer") {
    return {
      id: 12345,
      firstname: "John",
      lastname: "Doe",
      phone_number: "+33123456789",
      email: "john@doe.com",
      policies: [
        {
          type: "car",
          id: 12345,
        },
        {
          type: "home",
          id: 12345,
        }
      ]
    };
  }
  
  return {
    success: false,
    message: "invalid action"
  };

  // --- add your code above this line ---
}
